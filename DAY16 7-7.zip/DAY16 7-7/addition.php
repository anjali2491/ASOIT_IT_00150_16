<!DOCTYPE html>
<html>
<body>

<?php
$x = 5;
$y = 4;
$c=$x+$y;
echo "Answer is:",$c;
?>

</body>
</html>