<!DOCTYPE html>
<html>
<body>
<!-- <form method="post">
      enter first number:
      <input type="number" name="number1"><br><br>
      enter second number:
      <input type="number" name="number2"><br><br>
      <input type="submit" name="submit"><br><br>
</form> -->
<?php
// if(isset($_post['submit']))
// {
//       $number1=$_post['number1'];
//       $number2=$_post['number2'];
//       $sum=$number1+$number2;
//       echo "the sum of number1 and number2 is:".$sum;

// }
$x = 10;  
$y = 6;
echo "1. addition
      2. subtraction
      3. multiplication
      4. division";
echo "enter your choice:";
echo $x + $y;
echo $x-$y;
echo $x*$y;
echo $x/$y;
?>  

</body>
</html>
